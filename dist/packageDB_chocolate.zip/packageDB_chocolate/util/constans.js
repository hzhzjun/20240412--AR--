//巧卡图片检索
export const CARD_ID = {
  sp_card_1:"https://yun.duiba.com.cn/db_games/qiaolezi/card/card6.png",//巧卡1
  sp_card_2:"https://yun.duiba.com.cn/db_games/qiaolezi/card/card7.png",//巧卡2
  sp_card_3:"https://yun.duiba.com.cn/db_games/qiaolezi/card/card8.png",//巧卡3
  sp_card_4:"https://yun.duiba.com.cn/db_games/qiaolezi/card/card9.png",//巧卡4
  sp_card_5:"https://yun.duiba.com.cn/db_games/qiaolezi/card/card10.png",//巧卡5
  sp_total_card:"", //合成卡
  
}

// 分享标题
export const SHARE_TEXT = {
  'normal': '巧乐兹码上有奖，瓜分百万现金红包啦',
  'send': '叮咚～好友赠送卡片已送达',
  'want': '好友求赠卡，快去看看吧～'
}

// 分享图片
export const SHARE_IMG = {
  'normal': 'https://yun.duiba.com.cn/aurora/assets/811bf566061b5218204d5dd5e39dd2605b0120fc.png',
  'send': 'https://yun.duiba.com.cn/aurora/assets/811bf566061b5218204d5dd5e39dd2605b0120fc.png',
  'want': 'https://yun.duiba.com.cn/aurora/assets/811bf566061b5218204d5dd5e39dd2605b0120fc.png',
}