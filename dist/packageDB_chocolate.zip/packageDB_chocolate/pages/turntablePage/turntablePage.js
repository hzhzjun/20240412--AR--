import { getTurntableInfo } from "../../db_api/index";
import { SHARE_IMG, SHARE_TEXT } from "../../util/constans";
import { globalDBData } from "../../util/util";

// packageDB_chocolate/pages/turntablePage/turntablePage.js
const sensors = globalDBData.sensors;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    turntableInfo: {},
    /** 中奖弹窗 */
    isShowPrize: false,
    /** 谢谢参与 */
    isShowThanks: false,
    /** 规则 */
    isShowRule: false,
    popData: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getTurntableInfo();
    sensors.track("Qlz_24Wm_PageView", {
      referrer: "/packageDB_chocolate/pages/index/index",
      current_url: "/packageDB_chocolate/pages/turntablePage/turntablePage",
      page_name: "大转盘页面",
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: SHARE_TEXT.normal,
      path: '/packageDB_chocolate/pages/index/index',
      imageUrl: SHARE_IMG.normal
    }
  },

  /** 获取大转盘首页信息 */
  async getTurntableInfo() {
    const res = await getTurntableInfo();
    if (res?.success) {
      if (!!res.data?.options) {
        const _options = (res?.data?.options || []).filter(item => item?.prizeId != "thanks");
        res.data.options = _options;
      }
      this.setData({
        turntableInfo: res?.data || {}
      })
    }
  },
  /** 抽奖结束 */
  handleDrawEnd(e) {
    const prize = e.detail?.prize || {};
    if (prize?.prizeId != "thanks") {
      this.setData({
        isShowPrize: true,
        popData: prize
      })
    } else {
      this.setData({
        isShowThanks: true
      })
    }
    this.getTurntableInfo();
  },
  /** 关闭弹窗 */
  closeDialog(e) {
    console.log("E", e)
    const type = e.detail.type;
    switch(type) {
      case "getPrize": {
        this.setData({
          isShowPrize: false
        })
        break;
      }
      case "thanks": {
        this.setData({
          isShowThanks: false
        })
        break;
      }
      case "rule": {
        this.setData({
          isShowRule: false
        })
        break;
      }
    }
  },
  /** 唤起规则 */
  showRule() {
    sensors.track("Qlz_24Wm_PageClick", {
      current_url: "/packageDB_chocolate/pages/turntablePage/turntablePage",
      page_name: "大转盘页面",
      button_name: "规则",
    })
    this.setData({
      isShowRule: true
    })
  },
  /** 返回 */
  back() {
    wx.navigateBack()
  }
})