import {
  apiExchange,
  apiqueryUserSps
} from "../../db_api/index"
import {
  CARD_ID
} from "../../util/constans"
import sensors from '../../../module/sensorsdata.min';
// packageDB_chocolate/pages/exchangePage/exchangePage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    CARD_ID: CARD_ID,
    choselist: [],
    havelist: [],
    choseId: "",
    showExchange: false,
    tostMsg: "兑换的巧卡不足3张哦～",
    exchangeSuc: false,
    prizeInfo: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // console.log("!@!@!!@!@!")
    this.updataInfo()
    sensors.track("Qlz_24Wm_PageView", {
      referrer: "/packageDB_chocolate/pages/index/index",
      current_url: "/packageDB_chocolate/pages/exchangePage/exchangePage",
      page_name: "巧卡兑换中心",
    })
  },
  async updataInfo() {
    const resSp = await apiqueryUserSps()
    const {
      spList
    } = resSp.data;
    let list = ["sp_card_1", "sp_card_2", "sp_card_3", "sp_card_4", "sp_card_5"]
    let choselist = []
    let havelist = []
    for (let i = 0; i < spList.length; i++) {
      for (let n = 0; n < list.length; n++) {
        if (list[n] == spList[i].spId) {
          if (spList[i].spCount == 0) {
            choselist.push(spList[i])
          } else if (spList[i].spCount >= 2) {
            let item = spList[i]
            item.useCount = 0
            item.spCount = item.spCount - 1
            havelist.push(item)
          }
          break
        }
      }
    }
    this.setData({
      choselist,
      havelist
    })
    console.log("choselist", choselist, "havelist", havelist)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  addNum(e) {
    console.log("add", e.currentTarget.dataset.cardid)
    let list = this.data.havelist
    for (let i = 0; i < list.length; i++) {
      if (list[i].spId == e.currentTarget.dataset.cardid) {
        if (list[i].useCount < list[i].spCount) {
          list[i].useCount++
        }
        break
      }
    }
    this.setData({
      havelist: list
    }, () => {
      this.checkCard()
    })
  },
  cutNum(e) {
    console.log("cut", e.currentTarget.dataset.cardid)
    let list = this.data.havelist
    for (let i = 0; i < list.length; i++) {
      if (list[i].spId == e.currentTarget.dataset.cardid) {
        if (list[i].useCount > 0) {
          list[i].useCount--
        }
        break
      }
    }
    this.setData({
      havelist: list
    }, () => {
      this.checkCard()
    })
  },
  // 点击卡片
  // 选中想要兑换的卡片
  clickCard(e) {
    console.log(e.currentTarget.dataset.cardid)
    if (this.data.choseId == e.currentTarget.dataset.cardid) {
      this.setData({
        choseId: ""
      })
    } else {
      this.setData({
        choseId: e.currentTarget.dataset.cardid
      })
    }

  },
  checkCard() {
    let list = this.data.havelist
    let num = 0
    for (let i = 0; i < list.length; i++) {
      if (list[i].useCount > 0) {
        num = num + list[i].useCount
      }
    }
    if (num < 3) {
      this.setData({
        showExchange: false,
        tostMsg: "兑换的巧卡不足3张哦～"
      })
    } else if (num > 3) {
      this.setData({
        showExchange: false,
        tostMsg: "选择的巧卡超过3张啦～"
      })
    } else {
      this.setData({
        showExchange: true,
        tostMsg: ""
      })
    }
  },
  async doExchange() {
    if (!this.data.showExchange) {
      wx.showToast({
        title: this.data.tostMsg,
        icon: "none"
      })
      return
    }
    console
    if (!this.data.choseId) {
      wx.showToast({
        title: '请选择一张需要的巧卡~',
        icon: "none"
      })
      return
    }
    sensors.track("Qlz_24Wm_PageClick", {
      current_url: "/packageDB_chocolate/pages/exchangePage/exchangePage",
      page_name: "巧卡兑换中心",
      button_name: "确认兑换"
    })
    let list = this.data.havelist
    let showlist = []
    for (let i = 0; i < list.length; i++) {
      let item = {}
      if (list[i].useCount > 0) {
        item = {
          spId: list[i].spId,
          nums: list[i].useCount
        }
        showlist.push(item)
      }
      
    }
    let res = await apiExchange({
      data: {
        targetSpId: this.data.choseId,
        exchangeSpList: showlist
      }
    })
    if (res.success) {
      this.setData({
        prizeInfo: res.data.prize,
        exchangeSuc: true
      })
      this.updataInfo()
    } else {
      wx.showToast({
        title: res.message,
        icon: "none"
      })
    }
  },
  closePop() {
    this.setData({
      exchangeSuc: false
    })
  },
  back(){
    wx.navigateBack()
  },
})
