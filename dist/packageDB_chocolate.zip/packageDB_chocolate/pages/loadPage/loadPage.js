// packageDB_chocolate/pages/loadPage/loadPage.js
import {
  dateFormatter,
  globalDBData,
} from "../../util/util";
const sensors = globalDBData.sensors;

const productName = {
  "qcb": "巧脆棒产品包装",
  "qlg": "巧恋果产品包装",
  "xnb": "香奶棒产品包装",
  "sgq": "四个圈产品包装",
  "qsr": "巧丝绒产品包装"
}

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log("Loading", options)
    setTimeout(()=>{
      wx.redirectTo({
        url: `/packageDB_chocolate/pages/index/index?shareType=${options?.shareType}&cardId=${options?.cardId}${options?.inviteCode ? ("&inviteCode=" + options?.inviteCode) : ""}`,
      })
    },3000)

    console.error("来看看我的渠道生效了吗？？", options?.source, productName[options?.source])
    sensors.registerApp({
      product_name: "巧乐兹Chocliz",
      atv_page: "24年物码活动",
      utm_campaign: productName[options?.source],
    })

    globalDBData.source = productName[options?.source]

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})