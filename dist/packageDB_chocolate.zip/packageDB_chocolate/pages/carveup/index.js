const { apiCarveUpIndex, apiCarveUpDetails,apiInviteDetails, apiGetInviteCode } = require("../../db_api/index")
import { SHARE_IMG, SHARE_TEXT } from "../../util/constans"
import {formatTime} from "../../util/util"
import sensors from '../../../module/sensorsdata.min';

// packageDB_chocolate/pages/carveup/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    homeInfo: {},
    currentTab: 0,
    progress: -600,
    dataList:[],//瓜分明细
    inviteList:[],//邀请明细
    showInvitePop:false,//是否展示邀请人数反馈弹窗
    inviteInfo:null,//邀请人数弹窗数据
    inviteFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    console.log(wx.getStorageSync('db_loginToken'),"999999")
    //首页信息
    const { data } = await apiCarveUpIndex()
    // console.log(data)
    this.setData({ homeInfo: data })
    //邀请人数弹窗
    if(data.invitePop){
      this.setData({showInvitePop:true,inviteInfo:data.invitePop})
    }
    if(data.qualicationFlag){
      this.setData({inviteFlag:true})
    }
    if (data.inviteNum) { //更新进度条
      if(data.inviteNum == 2){
        this.setData({ progress: -500 })
      }
      if(data.inviteNum == 3){
        this.setData({ progress: -400 })
      }
      if(data.inviteNum == 4){
        this.setData({ progress: -300 })
      }
      if(data.inviteNum >= 5){
        this.setData({ progress: 0 })
      }
    }

    //邀请明细
    const { data: inviteData } = await apiInviteDetails()
    const data4 = inviteData.list?.map((v,i) => {
      return ({
        assistNickname:v.assistNickname,
        gmtCreate:formatTime(new Date(v.gmtCreate),3),
      })
    })
    // console.log(data4)
    this.setData({inviteList:data4})


    //瓜分明细
    const { data: data1 } = await apiCarveUpDetails()
    const data3 = data1.dataList.map((v,i) => {
      return ({
        divideDate:formatTime(new Date(v.divideDate),2),
        multipleNum:v.multipleNum,
        divideAmount:(v.divideAmount / 100).toFixed(2)
      })
    })
    this.setData({dataList:data3})

    sensors.track("Qlz_24Wm_PageView",{
      page_name: '瓜分页面',
      current_inflation_multiple:this.data.homeInfo?.currentMultiple || 0,
      current_url:`packageDB_chocolate/pages/carveup/index`
    })

  },

  changeTab(e) {
    // console.log(e.currentTarget.dataset['tab'],"index")
    const index = e.currentTarget.dataset['tab']
    // console.log(index)
    if (index == this.data.currentTab) return
    this.setData({ currentTab: index })

  },

  // 关闭邀请人数弹窗
  modalClose() {
    this.setData({
      showInvitePop: false
    })
  },

  back() {
    wx.navigateBack();
  },

  goshare(){
    sensors.track("Qlz_24Wm_PageClick",{
      page_name: '瓜分页面',
      button_name:"去邀请",
      current_url:`packageDB_chocolate/pages/carveup/index`
    })
  },

  shareBtn2Toast(){
    console.log("1111",this.data.homeInfo?.systemTime > this.data.homeInfo?.actEndTime)
    if(this.data.homeInfo?.systemTime > this.data.homeInfo?.actEndTime){
      wx.showToast({
        title: '活动已结束，感谢您的关注～',
        icon: "none"
      })
      return
    }
    if(!this.data.homeInfo?.qualicationFlag){
      wx.showToast({
        title: '还未获得瓜分资格哦，先去收集巧卡吧～',
        icon: "none"
      })
      return
    }

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  async getInviteCode() {
    let res = ''
    let link = `/packageDB_chocolate/pages/loadPage/loadPage`;
    
    if(this.data.inviteFlag) {
      res = await apiGetInviteCode();
      link = `/packageDB_chocolate/pages/loadPage/loadPage?shareType=normal&inviteCode=${res.data?.inviteCode}`
    }

    return {
      title: SHARE_TEXT.normal,
      path: link,
      imageUrl: SHARE_IMG.normal
    }

  },
  goshare3(){
      wx.showToast({
        title: '活动已结束，感谢您的关注～',
        icon: "none"
      })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
   
  
    // let res = ''
    // let link = `/packageDB_chocolate/pages/index/index`;
    
    // if(this.data.inviteFlag) {
    //   res = await apiGetInviteCode();
    //   link = `/packageDB_chocolate/pages/index/index?inviteCode=${res.data?.inviteCode}`
    // }
    const promise = this.getInviteCode();

    return {
      title: SHARE_TEXT.normal,
      path: '/packageDB_chocolate/pages/loadPage/loadPage',
      imageUrl: SHARE_IMG.normal,
      promise
    }
  }
})