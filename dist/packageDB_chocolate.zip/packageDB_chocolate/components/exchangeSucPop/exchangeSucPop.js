const { CARD_ID } = require("../../util/constans")

// packageDB_chocolate/components/exchangeSucPop/exchangeSucPop.js
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    prizeInfo:{},
    onClose:Function
  },

  /**
   * 组件的初始数据
   */
  data: {
    CARD_ID: CARD_ID,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    closePop(){
      // console.log(this.properties.onClose)
      this.triggerEvent("close")
    }
  }
})