// packageDB_chocolate/components/cardPrizePop/cardPrizePop.js
import sensors from '../../../module/sensorsdata.min';
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    prizeInfo:{
      "prizeVo": {
        "prizeName": String,
        "prizeImage": String,
        "prizeId": String
      },
      "cardVo": {
        "prizeName": String,
        "prizeImage": String,
        "prizeId": String
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

},

  /**
   * 组件的方法列表
   */
  methods: {
 // 点击确定关闭
 closeModal() {
  this.triggerEvent("myEvent");
  sensors.track("Qlz_24Wm_PopClick",{
    pop_name: '99-50优惠券',
    button_name: '开心收下',
    pop_type:"优惠券",
    current_url:"/packageDB_chocolate/components/cardPrizePop/cardPrizePop",
    page_name:"活动首页",
  })
},
}
})
