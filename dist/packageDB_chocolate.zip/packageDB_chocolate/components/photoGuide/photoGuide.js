// import { logExposure } from "../../db_api/index"
import { globalDBData } from "../../util/util"

Component({
  lifetimes: {
    async attached() {
      // console.error('jinlaime')
      // await logExposure({
      //   dpm: `${globalDBData.appID}.110.10.1`,
      // })
      wx.setStorageSync('photoGuide', 'hasGuide')
    }
  },
  methods: {
    closeModal() {
      this.triggerEvent("closeModal", 'showPhotoGuide')
      this.triggerEvent("showTakePhoto")
      
    },

    closeModal2() {
      this.triggerEvent("closeModal", 'showPhotoGuide')
    }
  }
})