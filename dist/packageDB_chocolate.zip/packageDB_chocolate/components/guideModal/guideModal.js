// import { logClick, logExposure } from "../../db_api/index";
import { globalDBData } from "../../util/util";
const sensors = globalDBData.sensors;
Component({
  lifetimes: {
    async attached() {

      sensors.track("Qlz_24Wm_PopExposure", {
        page_name: "首页",
        pop_name: '新人引导',
        current_url: "/packageDB_chocolate/pages/index/index"
        // button_name: '确定'
      })
      // sensors.track("Qlz_24Wm_PageView", {
      //   referrer: "/packageDB_chocolate/pages/index/index",
      //   current_url: "/packageDB_chocolate/pages/index/index",
      //   page_name: "新人引导",
      // })

      wx.setStorageSync('showGuide', true)
      // await logExposure({
      //   dpm: `${globalDBData.appID}.110.1.1`,
      // })
    }
  },
  methods: {
    async closeGuide() {
      sensors.track('Qlz_24Wm_PopClick', {
        page_name: "首页",
        pop_name: '新人引导',
        button_name: '关闭'
      })
      // await logClick({
      //   dpm: `${globalDBData.appID}.110.3.1`,
      // })
      this.triggerEvent("closeGuide", 'showNewGuide')
    },
    // 确定
    async doSure() {
      sensors.track("Qlz_24Wm_PopClick", {
        page_name: "首页",
        pop_name: '新人引导',
        button_name: '确定'
      })
      // await logClick({
      //   dpm: `${globalData.appID}.110.2.1`,
      // })

      this.triggerEvent("guideStep")
    }
  }
})