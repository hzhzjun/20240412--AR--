// packageDB_chocolate/components/carveupPop/carveupPop.js
import sensors from '../../../module/sensorsdata.min';
Component({
  lifetimes: {
    async attached() {
     
    },
    async ready(){
      console.log("1111111111111this.properties.dividePop?.multiple",this.properties.dividePop?.multiple) 
      sensors.track("Qlz_24Wm_PopExposure",{
        pop_name: this.properties.dividePop?.multiple, //'获得1.X倍数'
        page_name:"活动首页",
        pop_type:"红包",
        current_url:"/packageDB_chocolate/components/carveupPop/carveupPop"
      })
    }
  },
  /**
   * 组件的属性列表
   */
  properties: {
    dividePop: {
      multiple: Number,
      doubleFlag: Boolean,
      divideAmount: Number,
      divideMonth: String
      
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 点击确定关闭
    closeModal() {
      this.triggerEvent("myEvent");
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name:this.properties.dividePop?.multiple ,//'获得1.X倍数'
        button_name: '我知道了',
        pop_type:"红包",
        current_url:"/packageDB_chocolate/components/carveupPop/carveupPop",
        page_name:"活动首页",
      })
    },
  }
})
