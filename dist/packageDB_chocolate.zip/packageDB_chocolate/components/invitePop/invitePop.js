// packageDB_chocolate/components/invitePop/invitePop.js
import sensors from '../../../module/sensorsdata.min';
Component({
  lifetimes: {
    async attached() {
      sensors.track("Qlz_24Wm_PopExposure",{
        pop_name: '邀请成功',
        pop_type:"邀请",
        current_url:"/packageDB_chocolate/components/invitePop/invitePop",
        page_name:"瓜分页面",
      })
    }
  },
  /**
   * 组件的属性列表
   */
  properties: {
    inviteInfo:{
      inviteNum:Number,
      multipleValue:String
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 点击确定关闭
    closeModal() {
      this.triggerEvent("myEvent");
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '邀请成功',
        button_name: '我知道啦',
        current_url:"/packageDB_chocolate/components/invitePop/invitePop",
        page_name:"瓜分页面",
        pop_type:"邀请",
      })
    },
    goShare(){
      // console.error();("继续邀请好友")
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '邀请成功',
        button_name: '继续邀请好友',
        current_url:"/packageDB_chocolate/components/invitePop/invitePop",
        page_name:"瓜分页面",
        pop_type:"邀请",
      })
    }
  }
})
