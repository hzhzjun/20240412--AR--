import { getTurntableRule } from "../../db_api/index";

// packageDB_chocolate/components/turntableRule/turntableRule.js
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    rule: {
      type: String,
      value: ""
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    _rule: ""
  },

  lifetimes: {
    attached() {
      // this.getRuleInfo();
      
    }
  },

  observers: {
    rule: function() {
      console.log(this.properties.rule)
      const _rule = this.properties.rule.replace(/@@/g, "\n");
      this.setData({
        _rule: _rule
      })
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
     /** 关闭弹窗 */
    closeDialog() {
      this.triggerEvent("close", {type: "rule"});
    },
    /** 获取规则 */
    async getRuleInfo() {
      const res = await getTurntableRule();
      if (res?.success) {
        this.setData({
          rule: res?.data || ""
        })
      }
    }
  }
})