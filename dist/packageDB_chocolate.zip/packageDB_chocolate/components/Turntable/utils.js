const lockObj = {}
export const _throttle = (fun, delay = 2000) => {
    if (!lockObj[fun]) {
        lockObj[fun] = true
        fun()
        setTimeout(() => {
            lockObj[fun] = false
        }, delay)
    }
}

/** Toast */
export const Toast = (msg) => {
  wx.showToast({
    title: msg || "",
    icon: "none"
  })
}