
import { drawTurntable } from "../../db_api/index";
import { Toast, _throttle } from "./utils"
import { globalDBData } from "../../util/util"

const sensors = globalDBData.sensors;

/** 是否在转 */
let isPlay = false;

/** 过渡结束定时器 */
let timer = null

/**
 * 组件传入的几个值都是有用的
 * size  大转盘里面每个元素的尺寸，正方形，要改成其他形状直接改源码，会影响文案长度，要定制文案的展示直接改源码吧
 * imgSize 图片尺寸也是正方形，其他形状直接改源码
 * prizeList 奖品列表，传一个对象数组进来，不支持插槽，所以要支持其他元素直接改源码，文案和图片的位置直接调代码顺序
 * bodySize 放奖品圆盘的尺寸，用于设置锚点，大转盘的圆最好是正圆，不然的话改代码微调
 * 
 * 抽奖接口就不传入了，字段难统一在doDraw里改
 * 
 */

Component({
  properties: {
    /** 大转盘元素尺寸 */
    size: {
      type: Number,
      value: 160
    },
    /** 图片尺寸 */
    imgSize: {
      type: Number,
      value: 100
    },

    /** 数据 */
    prizeList: {
      type: Array,
      value: []
    },

    /** 转盘尺寸 */
    bodySize: {
      type: Number,
      value: 100
    },

    /** 奖品名key */
    nameKey: {
      type: String,
      value: "name"
    },

    /** 图片名key */
    iconKey: {
      type: String,
      value: "icon"
    },

    /** 剩余次数 */
    times: {
      type: Number,
      value: 0
    }

  },

  /**
   * 组件的初始数据
   */
  data: {
    /** 大转盘渲染元素 */
    renderList: [],
    /** 大转盘转动度数 */
    rotate: 0,
    /** 转盘style */
    style: "",
    /** 奖品信息 */
    prizeInfo: {}
  },

  observers: {
    prizeList() {
      this.initTurntable(this.properties.prizeList)
    }
  },

  lifetimes: {
    attached() {
      /** 初始化一下，防止意外退出导致被锁住了 */
      isPlay = false;
      timer = null;
      console.log("%c 数据", "font-size: 20px; color: rgba(255, 55, 0)", this.properties);
      this.initTurntable(this.properties.prizeList);
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /** 大转盘初始化 */
    initTurntable(prizeList) {
      const len = prizeList.length;
      const temp = [];
      for (let i = 0; i < len; i ++) {
        const rotate = 360 / len * (i + 0.5);
        temp.push({
          ...prizeList[i],
          rotate,
          name: prizeList[i]?.[this.properties.nameKey],
          icon: prizeList[i]?.[this.properties.iconKey],
        })
      }
      this.setData({
        renderList: temp,
      })
    },
    /** 先中个索引 */
    doDraw() {
      return _throttle(async () => {
        sensors.track("Qlz_24Wm_PageClick", {
          current_url: "packageDB_chocolate/pages/turntablePage/turntablePage",
          page_name: "大转盘页面",
          button_name: "开始抽奖",
        })
        if (this.properties.times <= 0) {
          Toast("暂无抽奖机会，请先验证棒签码获得抽奖机会吧～")
          return;
        }
        const res = await drawTurntable();
        if (res?.success) {
          const prize = res?.data?.prize || {};
          const index = this.data.renderList.findIndex(item => item?.prizeId == prize?.prizeId);
          this.setData({
            prizeInfo: prize
          })
          this.startTable(index);
        } else {
          Toast(res?.message || "")
        }
      })
    },
    /** 
     * 开抽！ index从0开始
     *  */
    startTable(index = null) {
      if (isPlay) return;
      if (index < 0 || index == null) {
        Toast("补充库存中，请稍后再来～")
        return;
      }
      isPlay = true;
      const rotate_item = 360 / this.properties.prizeList.length;
      const rotate = -1 * (index + 1) * rotate_item - 360 * 4 + rotate_item / 2;
      this.setData({
        rotate: rotate,
        style: `transform: rotate(${rotate}deg); transition: transform 2s ease-out;`,
      })
    },
    /** 过渡结束 */
    transitionEnd(e) {
      const _rotate = this.data.rotate % 360;
      this.setData({
        rotate: _rotate,
        style: `transform: rotate(${_rotate}deg); transition: transform 0.01s ease-out;`,
      }, () => {
        timer = setTimeout(() => {
          clearTimeout(timer);
          isPlay = false;
          this.triggerEvent("draw", { prize: this.data.prizeInfo });
        }, 200)
      })
    }
  }
})