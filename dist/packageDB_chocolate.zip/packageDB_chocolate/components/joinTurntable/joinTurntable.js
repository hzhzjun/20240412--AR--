// packageDB_chocolate/components/joinTurntable/joinTurntable.js
import { globalDBData } from "../../util/util"

const sensors = globalDBData.sensors;

Component({

  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  lifetimes: {
    attached() {
      sensors.track("Qlz_24Wm_PopExposure",{
        pop_name: '幸运大转盘弹窗',
        pop_type:"",
        current_url:"/packageDB_chocolate/components/joinTurntable/joinTurntable",
        page_name:"活动首页",
      })
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /** 关闭弹窗 */
    closeDialog() {
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '幸运大转盘弹窗',
        button_name: '稍后了解',
        pop_type:"",
        current_url:"/packageDB_chocolate/components/joinTurntable/joinTurntable",
        page_name:"活动首页",
      })
      this.triggerEvent("closeModal", "joinTurntable");
    },
    /** 前往大转盘页面 */
    navigateToTurntable() {
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '幸运大转盘弹窗',
        button_name: '立即参与',
        pop_type:"",
        current_url:"/packageDB_chocolate/components/joinTurntable/joinTurntable",
        page_name:"活动首页",
      })
      wx.navigateTo({
        url: '/packageDB_chocolate/pages/turntablePage/turntablePage',
      })
    }
  }
})