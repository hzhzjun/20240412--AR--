import {
  CARD_ID
} from "../../util/constans";

// packageDB_chocolate/components/getCardAndQuanPop/getCardAndQuanPop.js
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    getcardandquanInfo: {
      prizeId: ""
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    CARD_ID: CARD_ID
  },

  /**
   * 组件的方法列表
   */
  methods: {
    closeModal() {
      this.triggerEvent("myEvent");
    }
  }
})
