Component({
  data: {
    noticeText: ''
  },
  properties: {
    showNotice: Object
  },
  lifetimes: {
    attached() {
      // console.error("zxx", this)
      this.setData({
        noticeText: this.data.showNotice.noticeText
      })
    },
  },
  

  methods: {
    closeModal() {
      this.triggerEvent("closeNotice", 'showNotice')
    }
  }
})