// packageDB_chocolate/components/getDrawPrize/getDrawPrize.js
import { globalDBData } from "../../util/util"

const sensors = globalDBData.sensors;
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    popData: {
      type: Object,
      value: {}
    }
  },

  lifetimes: {
    attached() {
      sensors.track("Qlz_24Wm_PopExposure",{
        pop_name: '中奖弹窗',
        pop_type:"",
        current_url:"/packageDB_chocolate/components/getDrawPrize/getDrawPrize",
        page_name:"大转盘页面",
      })
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    /** 查看奖品 */
    navigateToPrize() {
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '中奖弹窗',
        button_name: '查看奖品',
        pop_type:"",
        current_url:"/packageDB_chocolate/components/getDrawPrize/getDrawPrize",
        page_name:"大转盘页面",
      })
      this.triggerEvent("close", {type: "getPrize"});
      wx.navigateTo({
        url: "/packageDB_chocolate/pages/prizePage/prizePage",
      })
    },
    /** 关闭弹窗 */
    closeDialog() {
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '中奖弹窗',
        button_name: '关闭',
        pop_type:"",
        current_url:"/packageDB_chocolate/components/getDrawPrize/getDrawPrize",
        page_name:"大转盘页面",
      })
      this.triggerEvent("close", {type: "getPrize"});
    },

  }
})