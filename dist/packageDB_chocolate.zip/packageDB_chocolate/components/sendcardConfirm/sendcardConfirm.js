// packageDB_chocolate/components/sendcardConfirm/sendcardConfirm.js
import sensors from '../../../module/sensorsdata.min';
Component({
  lifetimes: {
    async attached() {
      sensors.track("Qlz_24Wm_PopExposure",{
        pop_name: '确认赠送',
        current_url:"/packageDB_chocolate/components/sendcardConfirm/sendcardConfirm",
        page_name:"活动首页",
        pop_type:"赠送巧卡",
      })
    }
  },
  /**
   * 组件的属性列表
   */
  properties: {
    sendCardConfirmInfo:{
      cardId:String,
      cardImg:String,
      cardName:String
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    operateSend() {
      console.log("@!@!@!@!@!!@!!@!@1")
      this.triggerEvent('doSend');
      // this.triggerEvent("myEvent");
    },
    // 点击确定关闭
    closeModal() {
      this.triggerEvent("myEvent");
      sensors.track("Qlz_24Wm_PopClick",{
        pop_name: '确认赠送',
        button_name: '返回',
        current_url:"/packageDB_chocolate/components/sendcardConfirm/sendcardConfirm",
        page_name:"活动首页",
        pop_type:"赠送巧卡",
      })
    },
  }
})
